var CACHE_NAME = 'v1731146980758';

this.addEventListener('install', function (event) {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            return cache.addAll(["click.mp3",
"click2.mp3",
"css/app.a9e9a24d.css",
"done-word.mp3",
"done-word2.mp3",
"exitLevel.mp3",
"favicon-dark.png",
"favicon.png",
"fonts/Inter-Black.5f2ce7df.ttf",
"fonts/Inter-Medium.5ff1f2a9.ttf",
"fonts/Inter-Regular.515cae74.ttf",
"fonts/Inter-SemiBold.ec60b23f.ttf",
"fonts/LobsterTwo-Regular.3ba9370b.ttf",
"fonts/Roboto.290793a3.ttf",
"fonts/Robotobold.1fc6a83d.ttf",
"fonts/Ubuntu-Light.277289c5.ttf",
"icon.png",
"img/allStars.6840e0db.png",
"img/animals.b47ee0ca.png",
"img/bg-1.eb27f4bd.png",
"img/bg-2.2888be06.png",
"img/bg-3.611af637.png",
"img/bg-4.7925e94b.png",
"img/bg-new-big.c32256b6.png",
"img/bg-new.49476956.png",
"img/bg0.d6124419.png",
"img/bg1-big.4a42065d.png",
"img/bg1.0d3c9e6f.png",
"img/bg1.cb950347.png",
"img/bg2-big.c043e34a.png",
"img/bg2.6f7cddb5.png",
"img/bg2.b6af5e50.png",
"img/bg3-big.973ca197.png",
"img/bg3.52bc15a8.png",
"img/bg3.5664e8f4.png",
"img/bg4.d21772ae.png",
"img/bg5.658eb4f4.png",
"img/bg6.c5f489cb.png",
"img/bgCave-big.20d99b87.png",
"img/bgChanger.5164abe3.png",
"img/bgGreen.fb183d79.png",
"img/bgH-big.161722c6.png",
"img/bgH.9fb28d16.png",
"img/bgNew2024.6b840f90.png",
"img/bgNew2024horizont.d6119c25.png",
"img/bgNewYear-big.766ecb7d.png",
"img/bgNewYear.5c01c5e3.png",
"img/bgSpring-big.1458a52f.png",
"img/bgVertical.cf6d9916.png",
"img/birds.a5b8ef25.png",
"img/blackCross.e161f7d2.svg",
"img/changeBgLeft.9248bc72.svg",
"img/changeBgRight.90e09a87.svg",
"img/cinema.e39cbc93.png",
"img/cloud.9d2f7ba0.svg",
"img/crs.38b7c576.png",
"img/css_sprites.f6f58f7f.png",
"img/eightMarch.0db17385.png",
"img/event.b77be2b1.png",
"img/farm.c31b3816.png",
"img/fastener.20b82dce.svg",
"img/fbv.f4f1e5c3.png",
"img/games.4e879388.png",
"img/halloween.d915e671.png",
"img/head.872d561b.png",
"img/house.f57794c7.png",
"img/ic1.b72f5d83.png",
"img/ic2.07508a48.png",
"img/ic3.bec5b9ee.png",
"img/ic4.a9715eb7.png",
"img/ic5.5d373514.png",
"img/ic6.8ef77b9d.png",
"img/ic7.8814f235.png",
"img/ic8.b4d0a0f0.png",
"img/leaderboardBackground.cee458da.png",
"img/locationBackground.7427e51c.png",
"img/magicTales.9b95390e.png",
"img/map.03e2e157.png",
"img/map.0c23a0b6.png",
"img/map.2f455522.png",
"img/map.57f39a96.png",
"img/map.5d563c69.png",
"img/map.5e58b323.png",
"img/map.a686b49d.png",
"img/map.a8d4dd95.png",
"img/map.af8d2fdf.png",
"img/map.ee5f369a.png",
"img/map.fdfff6b0.png",
"img/map_port.18b0ced4.png",
"img/map_port.2fdfa60b.png",
"img/map_port.350a6f6a.png",
"img/map_port.88666140.png",
"img/map_port.894c1a2b.png",
"img/map_port.9c4e2860.png",
"img/map_port.9f6eb934.png",
"img/map_port.bf43d078.png",
"img/map_port.c7ce3856.png",
"img/map_port.e1136630.png",
"img/map_port.f59a88de.png",
"img/map_port.f830b9bd.png",
"img/map_port.ff96f213.png",
"img/menu-horizont.51f2a589.png",
"img/menu.e78c44bd.png",
"img/moneyBackground.f32e17d5.png",
"img/myLevelBackground.ae0d6ba2.png",
"img/newYear-map.4d876fce.png",
"img/newYear.0897eb6b.png",
"img/newYearIcon.ca468415.png",
"img/newYearSquirrel.ec351840.png",
"img/player1.16251bd0.svg",
"img/player2.982cc275.svg",
"img/settingsBackground.32b2568f.png",
"img/sq.464477de.png",
"img/star.01caf66f.svg",
"img/stm.212b60a9.png",
"img/user.e3ba0b69.png",
"img/valentines.45e5cf96.png",
"img/valentines.ad0c4f95.png",
"img/wfl.673a621b.png",
"index.html",
"js/app.be097a69.js",
"js/chunk-vendors.f3e77283.js",
"music.mp3",
"new-level.mp3",
"reset.min.css",
"rules1.png",
"rules1EN.png",
"rules2.png",
"rules2EN.png",
"star.mp3",
"word-was.mp3",
"word-was3.mp3",
"wrong-word.mp3",
"wrong-word2.mp3"]);
        })
    );
});
var CACHE_PREFIX = 'game-v';

this.addEventListener('activate', function (event) {
    event.waitUntil(
        caches.keys().then(keyList => {
            return Promise.all(keyList.map(key => {
                if (key.indexOf(CACHE_PREFIX) === 0 && key !== CACHE_NAME) {
                    return caches.delete(key);
                }
            }));
        })
    );
});

this.addEventListener('fetch', function (event) {
    if (
        event.request.method !== 'GET' ||
        event.request.url.indexOf('http://') === 0 ||
        event.request.url.indexOf('an.yandex.ru') !== -1
    ) {
        return;
    }
    event.respondWith(
        caches.match(event.request, {ignoreSearch: true}).then(function(response) {
            return response || fetch(event.request);
        })
    );
});
